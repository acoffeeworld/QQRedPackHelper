//
//  NSTextField+Action.h
//  QQPlugin
//
//  Created by TK on 2017/9/19.
//  Copyright © 2017年 tk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSTextField (Action)

+ (instancetype)tk_labelWithString:(NSString *)stringValue;

@end
