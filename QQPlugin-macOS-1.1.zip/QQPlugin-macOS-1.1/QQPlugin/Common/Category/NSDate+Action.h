//
//  NSDate+Action.h
//  WeChatPlugin
//
//  Created by TK on 2018/7/25.
//  Copyright © 2018年 tk. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Action)

- (BOOL)isToday;
- (BOOL)isYesterday;

@end
