//
//  QQ.h
//  QQPlugin-macOS
//
//  Created by TK on 2018/3/18.
//  Copyright © 2018年 TK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (QQ)

+ (void)hookQQ;

@end
